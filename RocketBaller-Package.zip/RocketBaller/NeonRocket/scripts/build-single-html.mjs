#!/usr/bin/env node
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const root = fileURLToPath(new URL('../', import.meta.url));
const args = process.argv.slice(2);
if (args.length && (args.length !== 2 || args[0] !== '--out')) {
  throw new Error('Usage: node scripts/build-single-html.mjs [--out path]');
}
const output = path.resolve(root, args[1] || '../RocketBaller.html');

const result = await build({
  absWorkingDir: root,
  entryPoints: ['public/game.js'],
  bundle: true,
  write: false,
  format: 'esm',
  platform: 'browser',
  target: 'es2022',
  minify: true,
  sourcemap: false,
  plugins: [{
    name: 'neon-root-imports',
    setup(plugin) {
      plugin.onResolve({ filter: /^\/(?:vendor|shared|network-interpolation|rocketsim-playable-core)/ }, ({ path: specifier }) => {
        const clean = specifier.split('?')[0];
        if (clean === '/vendor/three.module.js') return { path: path.join(root, 'node_modules/three/build/three.module.js') };
        if (clean.startsWith('/shared/')) return { path: path.join(root, clean.slice(1)) };
        if (clean === '/network-interpolation.js') return { path: path.join(root, 'public/network-interpolation.js') };
        if (clean === '/rocketsim-playable-core.js') return { path: path.join(root, 'public/rocketsim-playable-core.js') };
        return { errors: [{ text: `Unsupported application import: ${specifier}` }] };
      });
      plugin.onResolve({ filter: /^node:/ }, ({ path: specifier }) => ({ path: specifier, external: true }));
    }
  }]
});

const javascript = result.outputFiles[0].text.replace(/<\/script/gi, '\\x3c/script');
const css = (await readFile(path.join(root, 'public/style.css'), 'utf8'))
  .replace(/^@import\s+url\([^\n]+\);\s*\n/m, '')
  .replace(/<\/style/gi, '<\\/style');
let html = await readFile(path.join(root, 'public/index.html'), 'utf8');
html = html.replace(/<link rel="stylesheet" href="[^"]+">/, `<style>${css}</style>`);
html = html.replace(/<script src="\/socket\.io\/socket\.io\.js"><\/script>\s*/, '');
for (const id of ['create', 'join', 'code', 'novaDuel']) {
  const control = new RegExp(`(<(?:button|input)\\b[^>]*id="${id}"[^>]*)(>)`);
  if (!control.test(html)) throw new Error(`Missing offline-disabled control: ${id}`);
  html = html.replace(control, '$1 disabled aria-describedby="single-file-note"$2');
}
html = html.replace(
  '<p class="offline-note">',
  '<p id="single-file-note" class="offline-note">OFFLINE SINGLE-FILE BUILD. Private rooms and live spectating need a server.</p>\n      <p class="offline-note">'
);
html = html.replace('CONNECTING TO SERVER…', 'SOLO-ONLY DEMO · OFFLINE');
const offlineSocketAndGame = `<script>
    (() => {
      const offlineSocket = Object.freeze({
        connected: false,
        disconnected: true,
        on() { return this; },
        emit() { return this; },
        timeout() { return this; },
        async emitWithAck() { throw new Error('SOLO-ONLY DEMO: no multiplayer server.'); }
      });
      window.io = () => offlineSocket;
    })();
  </script>
  <script type="module">${javascript}</script>
  <aside id="source-credits" hidden style="position:fixed;bottom:12px;left:50%;transform:translateX(-50%);z-index:1000;max-width:calc(100vw - 24px);padding:10px 14px;border:1px solid #6889c5;border-radius:8px;background:#080d1af2;color:#edf2ff;font:12px/1.5 system-ui,sans-serif;text-align:center">
    RocketBaller uses <a style="color:#9edcff" href="https://github.com/airope/neon-rocket" target="_blank" rel="noopener">Neon Rocket 3D by airope</a> under the <a style="color:#9edcff" href="https://github.com/airope/neon-rocket/blob/main/LICENSE" target="_blank" rel="noopener">MIT License</a>. This standalone copy bundles RocketSim, Three.js, Rapier, Cannon-es, and their license notices. Press J to close.
  </aside>
  <script>
    addEventListener('keydown', event => {
      if (event.code === 'KeyJ' && !event.repeat) {
        const panel = document.getElementById('source-credits');
        panel.hidden = !panel.hidden;
      } else if (event.code === 'Escape') {
        document.getElementById('source-credits').hidden = true;
      }
    });
  </script>`;
html = html.replace('<script type="module" src="/game.js?v=22"></script>', () => offlineSocketAndGame);
await writeFile(output, html);
console.log(`Single-file offline game written to ${output} (${Buffer.byteLength(html)} bytes).`);
