import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));

test('single HTML build keeps the bundled game intact for direct offline opening', async () => {
  const temp = await mkdtemp(path.join(tmpdir(), 'neon-single-html-'));
  try {
    const output = path.join(temp, 'RocketBaller.html');
    const result = spawnSync(process.execPath, ['scripts/build-single-html.mjs', '--out', output], {
      cwd: root,
      encoding: 'utf8',
    });
    assert.ifError(result.error);
    assert.equal(result.status, 0, result.stderr);

    const html = await readFile(output, 'utf8');
    const moduleMatch = html.match(/<script type="module">([\s\S]*?)<\/script>/);
    assert.ok(moduleMatch, 'the game must be inline, not loaded from a blob or separate file');
    assert.doesNotMatch(html, /<script\b[^>]*\bsrc=/);
    assert.doesNotMatch(html, /<link\b[^>]*rel="stylesheet"/);
    assert.doesNotMatch(html, /createObjectURL|import\(appUrl\)/);
    assert.match(html, /OFFLINE SINGLE-FILE BUILD/);
    assert.match(html, /source-credits/);
    assert.doesNotMatch(moduleMatch[1], /<\/script/i);

    const modulePath = path.join(temp, 'inline-game.mjs');
    await writeFile(modulePath, moduleMatch[1]);
    const syntax = spawnSync(process.execPath, ['--check', modulePath], { encoding: 'utf8' });
    assert.ifError(syntax.error);
    assert.equal(syntax.status, 0, syntax.stderr);
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
});
